const sharedConfig = require("tailwind-config-custom/tailwind.config.js");

module.exports = {
  presets: [sharedConfig],
};
