from django.apps import AppConfig


class AnalyticsConfig(AppConfig):
    name = "plane.analytics"
