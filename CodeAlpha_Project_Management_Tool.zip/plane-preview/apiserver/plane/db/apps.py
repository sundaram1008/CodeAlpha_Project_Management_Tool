from django.apps import AppConfig


class DbConfig(AppConfig):
    name = "plane.db"
