from django.apps import AppConfig


class SpaceConfig(AppConfig):
    name = "plane.space"
