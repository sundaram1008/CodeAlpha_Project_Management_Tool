"use client";

export default function RootErrorPage() {
  return (
    <div>
      <p>Something went wrong.</p>
    </div>
  );
}
