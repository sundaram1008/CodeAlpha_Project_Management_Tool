from django.apps import AppConfig


class AppApiConfig(AppConfig):
    name = "plane.app"
